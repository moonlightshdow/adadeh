<?php
// Class sederhana untuk contoh
class User {
    public $username;
    public $isAdmin = false;

    public function __construct($username) {
        $this->username = $username;
    }

    // Fungsi __wakeup untuk simulasi kerentanan
    public function __wakeup() {
        if ($this->isAdmin) {
            echo "Welcome, Admin!";
        } else {
            echo "Welcome, $this->username!";
        }
    }
}

// Simulasi menerima input serialized dari pengguna
if (isset($_GET['data'])) {
    $data = $_GET['data'];

    // WARNING: Ini adalah proses deserialization yang tidak aman
    $user = unserialize($data);

    // Output dari proses deserialization
    echo "<pre>";
    var_dump($user);
    echo "</pre>";
} else {
    echo "Masukkan serialized data di parameter `data` (contoh: ?data=...)";
}
