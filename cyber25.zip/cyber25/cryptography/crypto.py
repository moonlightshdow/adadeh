from string import ascii_lowercase

def header():
    print('''

============================================
                LKS encryptor
============================================
          
          ''')

def check_input(kata):
    for i in kata:
        if i not in mylist:
            print('Input tidak valid, hanya menerima [a-z]')
            return True
    return False

def linearsearch(mylist, karakter):
    for i in range(len(mylist)):
        if mylist[i] == karakter:
            return i
    return -1

def encrypt(kata):
    result = ''
    for i in kata:
        index = linearsearch(mylist, i)
        if index % 2 == 0:
            result += mylist[(index + 698) % 26]
        else:
            result += mylist[(index + 404) % 26]
    return result

if __name__ == '__main__':
    mylist = [ i for i in ascii_lowercase]
    try:
        header()
        kata = input('Masukan kata yang ingin di enkripsi [a-z] \n--> ')
        while check_input(kata):
            kata = input('Masukan kata yang ingin di enkripsi [a-z] \n--> ')
        enc = encrypt(kata)
        print("\nBerikut adalah pesan yang telah di enkripsi : {}".format(enc))
    except:
        print('\nbye!')

# Berikut adalah pesan yang telah di enkripsi : ywaowfyudvafehqowbcwhgzwoegrwzwigfedhkcfwtexwreuwwcwidwbcpwbcahebeiwv